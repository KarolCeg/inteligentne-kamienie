// C++ code
//
const int led = 5;
const int button = 2; //pozwala na przerwanie
int tryb = 1;
//8-bitowe liczniki
void setup()
{
  pinMode(led,OUTPUT);
  pinMode(button, INPUT_PULLUP); //high
  attachInterrupt(digitalPinToInterrupt(button), interrupt_button, FALLING);
  
}
void interrupt_button()
{
	if(tryb == 3)
	{
  tryb = 1;
	}
  	else
    {
   tryb+=1;
    }
}
void wolne_miganie()
{
  	Serial.println("wolne_miganie");
      digitalWrite(led, HIGH);
  	delay(2000);
  	digitalWrite(led, LOW);
  	delay(2000);
}
void szybkie_miganie()
{
  	Serial.println("szybkie_miganie");
	digitalWrite(led, HIGH);
  	delay(300);
  	digitalWrite(led, LOW);
  	delay(300);
}
void zmiana_jasnosci(){
  	Serial.println("zmiana_jasnosci");
	for(int i=0; i<255;i++){analogWrite(led, i);delay(10);}
	for(int i=255; i>0;i--){analogWrite(led, i);;delay(10);}
}
void loop()
{
 if(tryb==1){
    wolne_miganie();
  }
  else if(tryb==2){
   szybkie_miganie();
  }
  else if(tryb==3){
   zmiana_jasnosci();
  }

}